export const videoUrlList = [
  [
    "../assets/healingVideos/thumb-1.png",
    "../assets/healingVideos/thumb-2.png",
    "../assets/healingVideos/thumb-3.png",
    "../assets/healingVideos/thumb-4.png",
    "../assets/healingVideos/thumb-5.png",
    "../assets/healingVideos/thumb-6.png",
  ],
  [
    "../assets/healingVideos/thumb-1.png",
    "../assets/healingVideos/thumb-2.png",
    "../assets/healingVideos/thumb-3.png",
    "../assets/healingVideos/thumb-4.png",
    "../assets/healingVideos/thumb-5.png",
    "../assets/healingVideos/thumb-6.png",
  ],
  [
    "../assets/healingVideos/thumb-1.png",
    "../assets/healingVideos/thumb-2.png",
    "../assets/healingVideos/thumb-3.png",
    "../assets/healingVideos/thumb-4.png",
    "../assets/healingVideos/thumb-5.png",
    "../assets/healingVideos/thumb-6.png",
  ],
  [
    "../assets/healingVideos/thumb-1.png",
    "../assets/healingVideos/thumb-2.png",
    "../assets/healingVideos/thumb-3.png",
    "../assets/healingVideos/thumb-4.png",
    "../assets/healingVideos/thumb-5.png",
    "../assets/healingVideos/thumb-6.png",
  ],
];

export const videoContentList = [
  [
    "낮잠자는 고양이",
    "앉아있는 개",
    "늑대",
    "청둥오리",
    "물가의 새",
    "바다거북이",
  ],
  [
    "낮잠자는 고양이",
    "앉아있는 개",
    "늑대",
    "청둥오리",
    "물가의 새",
    "바다거북이",
  ],
  [
    "낮잠자는 고양이",
    "앉아있는 개",
    "늑대",
    "청둥오리",
    "물가의 새",
    "바다거북이",
  ],
  [
    "낮잠자는 고양이",
    "앉아있는 개",
    "늑대",
    "청둥오리",
    "물가의 새",
    "바다거북이",
  ],
];

export const videoLinkList = [
  [
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
  ],
  [
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
  ],
  [
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
  ],
  [
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
    "https://wetube-xanqus.s3-ap-northeast-1.amazonaws.com/video/aa.mp4",
  ],
];
